/* File: cmd5.c */

/*
 * Copyright (c) 1997 Ben Harrison, James E. Wilson, Robert A. Koeneke
 *
 * This software may be copied and distributed for educational, research,
 * and not for profit purposes provided that this copyright and statement
 * are included in all such copies.  Other copyrights may also apply.
 */

#include "angband.h"

/*
 * Hack -- display an object kind in the current window
 *
 * Include list of usable spells for readible books
 */
void display_koff(int k_idx)
{
    int y;

    object_type* i_ptr;
    object_type object_type_body;

    char o_name[80];

    /* Erase the window */
    for (y = 0; y < Term->hgt; y++)
    {
        /* Erase the line */
        Term_erase(0, y, 255);
    }

    /* No info */
    if (!k_idx)
        return;

    /* Get local object */
    i_ptr = &object_type_body;

    /* Prepare the object */
    object_wipe(i_ptr);

    /* Prepare the object */
    object_prep(i_ptr, k_idx);

    /* Describe */
    object_desc_spoil(o_name, sizeof(o_name), i_ptr, FALSE, 0);

    /* Mention the object name */
    Term_putstr(0, 0, -1, TERM_WHITE, o_name);
}
