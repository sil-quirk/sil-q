/* --------------------------------------------------------------------
 *  src/metarun.c   (2025-07-06)   – final, crash-free, warning-free
 * --------------------------------------------------------------------
 *  Tracks a “meta-run” that ends after 15 Silmarils (win) or
 *  15 deaths (lose).  Finished runs are appended to meta.raw so
 *  the entire history is preserved.  Includes:
 *     • list_metaruns()  – compact history view
 *     • print_metarun_stats() – details for current run
 * -------------------------------------------------------------------- */
#include "angband.h"
#include "metarun.h"
#include "log.h"
#include "platform.h"    /* path_build(), fd_*, MKDIR         */

#include <string.h>
#include <stdlib.h>
#include <time.h>

#include <stdio.h>  

/* --------------------------------------------------------------- */
/*  metarun.c : quick-and-dirty logger                             */
/* --------------------------------------------------------------- */

/* =========================  constants  ========================= */
#define META_RAW          "meta.raw"
#define META_SUBDIR       "metaruns"
#define CURSE_MENU_LINES  3

/* =========================  globals  =========================== */
static metarun *metaruns    = NULL;
static s16b     metarun_max = 0;
static s16b     current_run = 0;
bool            metarun_created = false;

/* ==================  tiny local helpers  ======================= */
static int rng_int(int max) { return max ? (int)(rand() % max) : 0; }

static void build_meta_path(char *buf, size_t len,
                            const metarun *m, const char *leaf)
{
    char sub[128];
    if (m)
        strnfmt(sub, sizeof sub, "%s/%08u/%s",
                META_SUBDIR, (unsigned)m->id, leaf);
    else
        strnfmt(sub, sizeof sub, "%s/%s", META_SUBDIR, leaf);
    path_build(buf, len, ANGBAND_DIR_APEX, sub);
}

static void reset_defaults(metarun *m)
{
    log_info("Initializing new metarun with default values");
    memset(m, 0, sizeof(*m));
    m->id          = 1;
    m->last_played = (u32b)time(NULL);
    m->curses_lo   = 0;
    m->curses_hi   = 0;
    m->curses_seen = 0;   
    m->deaths      = 0;
    m->silmarils   = 0;
    log_debug("After init: curses_seen = 0x%08X", m->curses_seen);
}

/* ensure directory apex/metaruns/NNNNNNNN exists */
static void ensure_run_dir(const metarun *m)
{
    char dir[1024];
    path_build(dir, sizeof dir, ANGBAND_DIR_APEX, META_SUBDIR); MKDIR(dir);
    strnfmt(dir, sizeof dir, "%s/%08u", META_SUBDIR, (unsigned)m->id);
    path_build(dir, sizeof dir, ANGBAND_DIR_APEX, dir);         MKDIR(dir);
}

static void meta_log(const char *fmt, ...)
{
    char fn[1024];
    build_meta_path(fn, sizeof fn, NULL, "log.txt");

    FILE *fp = fopen(fn, "a");
    if (!fp) return;

    va_list ap;
    va_start(ap, fmt);
    vfprintf(fp, fmt, ap);
    va_end(ap);

    fprintf(fp, "\n");
    fclose(fp);
}

/* forward declarations */
static void choose_escape_curses(int n);
static void check_run_end(void);
static void start_new_metarun(void);

/* ----------------------------------------------------------------
 * Flush the live 2-bit counters into the on-disk words
 * ---------------------------------------------------------------- */
static void curses_pack_words(void)
{
    u32b lo = 0, hi = 0;

    for (int id = 0; id < 32; id++) {
        u32b cnt = CURSE_GET(id) & 0x3;        /* 0–3 stacks */
        if (id < 16)
            lo |= cnt << (id * 2);             /* bits 0,2,4 … 30 */
        else
            hi |= cnt << ((id - 16) * 2);
    }

    metar.curses_lo = lo;
    metar.curses_hi = hi;
}

/* ----------------------------------------------------------------
 * Expand the on-disk words into the live 2-bit counters
 * (call straight after reading the struct)
 * ---------------------------------------------------------------- */
static void curses_unpack_words(void)
{
    log_debug("curses_unpack_words: before - curses_seen=0x%08X", metar.curses_seen);
    
    u32b lo = metar.curses_lo;          
    u32b hi = metar.curses_hi;

    for (int id = 0; id < 32; id++) {
        u32b cnt = (id < 16)
                 ? (lo >> (id * 2)) & 0x3    
                 : (hi >> ((id - 16) * 2)) & 0x3;

        CURSE_SET(id, (byte)cnt);            
    }
    
    log_debug("curses_unpack_words: after - curses_seen=0x%08X", metar.curses_seen);
}


/* =======================  load / save  ========================= */
errr load_metaruns(bool create_if_missing)
{
    char fn[1024];
    int  fd;

    build_meta_path(fn, sizeof fn, NULL, META_RAW);
    fd = fd_open(fn, O_RDONLY);

    if (fd < 0 && create_if_missing) {
        log_info("Creating new metarun file: %s", fn);
        FILE_TYPE(FILE_TYPE_DATA);
        fd = fd_make(fn, 0644);
        if (fd < 0) return -1;

        metarun seed; reset_defaults(&seed);
        fd_write(fd, (cptr)&seed, sizeof seed);
        fd_close(fd);
        fd = fd_open(fn, O_RDONLY);
        metarun_created = true;
    }
    else log_info("Loading existing metarun file: %s", fn);
    if (fd < 0) return -1;

    metarun_max = (s16b)(fd_file_size(fd) / sizeof(metarun));
    metaruns    = C_ZNEW(metarun_max, metarun);
    fd_read(fd, (char*)metaruns, metarun_max * sizeof(metarun));
    fd_close(fd);

    /* choose current run */
    u32b latest = 0;
    for (s16b i = 0; i < metarun_max; i++) {
        if (metaruns[i].last_played > latest ||
            (metaruns[i].last_played == latest && i > current_run))
        {
            latest      = metaruns[i].last_played;
            current_run = i;
        }
    }
    metar = metaruns[current_run];

    /* ensure its per-run directory exists */
    ensure_run_dir(&metar);
    curses_unpack_words();    /* NEW: expand words into live table */
    return 0;
}

/* ------------------------------------------------------------------ *
 *  Safely write the meta-run array.  Bail out if the indices look     *
 *  wrong – avoids dereferencing a freed/reallocated block.           *
 * ------------------------------------------------------------------ */
errr save_metaruns(void)
{
    meta_log("[SAVE] enter  id=%u  deaths=%u  sils=%u  lo=%08X  hi=%08X",
             metar.id, metar.deaths, metar.silmarils,
             metar.curses_lo, metar.curses_hi);

    if (!metaruns || current_run < 0 || current_run >= metarun_max) {
        meta_log("[SAVE] ABORT – corrupted pointer safety-check hit");
        return -1;
    }

    curses_pack_words();      /* NEW: ensure words hold 2-bit data */

    char fn[1024];
    build_meta_path(fn, sizeof fn, NULL, META_RAW);

    metar.last_played      = (u32b)time(NULL);
    metaruns[current_run] = metar;            /* safe: array is valid */

    /* Use standard C file operations instead of the problematic fd_* functions */
    FILE *fp = fopen(fn, "wb");
    if (!fp) {
        meta_log("[SAVE] ABORT – fopen() failed for writing (errno=%d)", errno);
        return -1;
    }

    size_t bytes_to_write = metarun_max * sizeof(metarun);
    size_t bytes_written = fwrite(metaruns, 1, bytes_to_write, fp);
    
    if (bytes_written != bytes_to_write) {
        meta_log("[SAVE] ABORT – fwrite() failed (wrote %zu of %zu bytes, errno=%d)", 
                 bytes_written, bytes_to_write, errno);
        fclose(fp);
        return -1;
    }
    
    fclose(fp);
    
    meta_log("[SAVE] ok – wrote %zu bytes to %s", bytes_to_write, fn);

    return 0;
}

int any_curse_flag_active(u32b flag)
{
    /* Intended for CUR flags such as CUR_NOCHOICE. */
    return (curse_flag_count_cur(flag) > 0);
}

/* ---------------------------------------------------------------
 * Pick a curse at random, respecting weights, stacks, caps,
 * and the RHF_CURSE tail-lift.
 * ------------------------------------------------------------- */
static int weighted_random_curse(void)
{
    long total = 0;
    int  w_max = 1;

    /* Does the hero’s lineage carry the flag? */
    bool tilt = (p_info[p_ptr->prace].flags  & RHF_CURSE) ||
                (c_info[p_ptr->phouse].flags & RHF_CURSE);

    /* Pass 1 – find the largest weight and (later) build the total */
    for (int i = 0; i < z_info->cu_max; i++)
    {
        if (!cu_info[i].name) continue;          /* ← unused slot */
        byte w   = cu_info[i].weight ? cu_info[i].weight : 1;
        if (w > w_max) w_max = w;
    }

    /* Pass 2 – sum effective weights */
    for (int i = 0; i < z_info->cu_max; i++)
    {
        if (!cu_info[i].name) continue;          /* ← unused slot */
        byte w   = cu_info[i].weight ? cu_info[i].weight : 1;
        byte cnt = CURSE_GET(i);
        byte cap = cu_info[i].max_stacks;
        if (cap && cnt >= cap) continue;           /* cap reached */

        long base = tilt
            ? w + ((w_max + 1 - w) >> 1)           /* lift the tail */
            : w;

        total += base / (cnt + 1);
    }

    if (!total) return rng_int(z_info->cu_max);    /* safety net */

    /* Pass 3 – roulette wheel */
    long pick = rng_int(total), run = 0;
    for (int i = 0; i < z_info->cu_max; i++)
    {
        if (!cu_info[i].name) continue;          /* ← unused slot */
        byte w   = cu_info[i].weight ? cu_info[i].weight : 1;
        byte cnt = CURSE_GET(i);
        byte cap = cu_info[i].max_stacks;
        if (cap && cnt >= cap) continue;

        long base = tilt
            ? w + ((w_max + 1 - w) >> 1)
            : w;

        long eff = base / (cnt + 1);
        run += eff;
        if (pick < run) return i;
    }

    return rng_int(z_info->cu_max);                /* unreachable */
}

void add_curse_stack(int idx)
{
    /* respect per-curse stack cap */
    if (cu_info[idx].max_stacks &&
        CURSE_GET(idx) >= cu_info[idx].max_stacks)
        return;

    CURSE_ADD(idx, 1);
    save_metaruns();
}

int menu_choose_one_curse(void)
{

    /* if any active curse has the “no‐choice” flag, skip the menu */
    if (any_curse_flag_active(CUR_NOCHOICE))
        return weighted_random_curse();

    int pick[CURSE_MENU_LINES], sel;

    for (int i = 0; i < CURSE_MENU_LINES; i++) {
        bool dup;
        do {
            dup     = false;
            pick[i] = weighted_random_curse();
            for (int j = 0; j < i; j++)
                if (pick[i] == pick[j]) { dup = true; break; }
            
            byte cap = cu_info[pick[i]].max_stacks;
            if (cap && CURSE_GET(pick[i]) >= cap) { dup = true; continue; }

        } while (dup);
    }

    screen_save();  Term_clear();
    c_prt(TERM_YELLOW,
          "Dark powers demand their price – choose your curse:", 1, 1);

    /* dynamic vertical layout – ask util.c to count wrapped lines   */
    int row = 3;                                     /* first free row */
    text_out_hook = text_out_to_screen;
    text_out_wrap = Term->wid - 2;                   /* full width     */

    for (int i = 0; i < CURSE_MENU_LINES; i++) {
        curse_type *cu = &cu_info[pick[i]];

        /* ---- name line ---- */
        c_put_str(TERM_L_RED,
                  format("%c) %s", 'a'+i, cu_name + cu->name),
                  row, 2);

        /* ---- poem (D: line) – wrapped ---- */
        const char *txt = cu_text + cu->text;
        int need = count_wrapped_lines(txt, text_out_wrap, 4); 

        Term_gotoxy(4, row+1);      /* indent poem two spaces further */
        text_out_c(TERM_SLATE, txt);

        /* ---- OPTIONAL effect (P: line) ---------------------------- */
#ifdef DEBUG_CURSES
        const char *pow = cu_text + cu->power;
        if (*pow)                             /* skip if no P: line   */
        {
            int need_pow = count_wrapped_lines(pow, text_out_wrap, 4);
            Term_gotoxy(4, row + need + 1);   /* right under the poem */
            text_out_c(TERM_L_RED, pow);   /* colour = violet      */
            row += need + need_pow + 2;       /* poem + effect + gap  */
        }
        else
#endif
            row += need + 2;                  /* poem + blank line    */
    }

    c_put_str(TERM_L_DARK, "Press a, b or c.", row, 2);
    sel = -1;
    while (sel < 0 || sel >= CURSE_MENU_LINES) sel = inkey() - 'a';
    screen_load();
    return pick[sel];
}


/* ------------------------------------------------------------------ *
 *  Debug helper – wipe every active curse for the current meta-run.  *
 * ------------------------------------------------------------------ */
void metarun_clear_all_curses(void)
{
    metar.curses_lo = 0;
    metar.curses_hi = 0;
    metar.curses_seen = 0;        
    save_metaruns();
}

/**
 * Grant escape curses after a metarun.
 * If any active curse has the CUR_NOCHOICE bit, only one curse is rolled.
 */
static void choose_escape_curses(int n)
{
    /* If “No-Choice” is active on any curse, give only one roll            */
    int rolls = any_curse_flag_active(CUR_NOCHOICE) ? 1 : n;

    for (int i = 0; i < rolls; i++) {
         int idx = menu_choose_one_curse();
         add_curse_stack(idx);
         msg_format("The curse of %s binds your fate…",
                    cu_name + cu_info[idx].name);
         message_flush();
}
}

/* ------------- debug macro ----------------------------------------- */
// #ifdef DEBUG
// # define log_info(fmt, ...)  fprintf(stderr, "[metarun] " fmt "\n", ##__VA_ARGS__)
// #else
// # define log_info(fmt, ...)  ((void)0)
// #endif


/* ------------------------------------------------------------------ *
 *  Main entry point used by game exits, deaths, escapes, etc.        *
 *  NOTE: save_metaruns() comes **after** check_run_end() so that     *
 *  any realloc in start_new_metarun() has already finished.          *
 * ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ *
 *  Main entry point used by game exits, deaths, escapes, etc.        *
 * ------------------------------------------------------------------ */
/*
/*
 * Metarun narrative & exit logic — refactor **v4** (30 Jul 2025)
 * ------------------------------------------------------------------
 *  ✧ Re‑orders the sequence so NOTHING is overwritten:
 *      0. Escape‑curse chooser (UI)  → clears screen once finished.
 *      1. Chosen‑curse line(s).
 *      2. Victory banner & Silmaril count paragraph.
 *      3. Temptation of Treachery (escalating 1‑3 lines).
 *      4. Story Fragment (depends on Silmarils & Treachery flag).
 *      5. Echoes of Kinslaying (escalating 1‑3 lines)
 *      6. Final pause, then deferred side‑effects.
 *
 *  ✧ `choose_escape_curses_ui()` now **returns** the indices chosen and
 *    does NOT leave the menu clutter on screen. We re‑render the
 *    “The curse of X binds your fate.” lines after a clean clear.
 *
 *  ✧ Adds `print_story_fragment()` – a short narrative bridge keyed off
 *    Silmaril count (1‑3) and whether treachery was overcome.
 *
 *  ✧ Tested matrix: {treachery flag × kinslayer flag × silmarils (1‑3)}
 *    All show in the intended order with no garbled overlaps.
 */

/********************  Small UI helpers  ***************************/

static void print_heading(cptr title, byte attr)
{
    int w, h; Term_get_size(&w, &h);
    int cx, cy; Term_locate(&cx, &cy);
    if (cy < 0 || cy >= h) cy = 0;

    c_prt(attr, title, cy, 1);
    Term_gotoxy(1, cy + 1);
}

static void print_paragraph(cptr txt, byte attr)
{
    text_out_hook   = text_out_to_screen;
    text_out_indent = 1;
    text_out_wrap   = Term->wid - 2;

    Term_addstr(0, attr, "");
    text_out_c(attr, txt);
    text_out("\n");
}

static cptr curse_display_name(int idx)
{
    cptr raw = cu_name + cu_info[idx].name;
    if (strncmp(raw, "Curse of ", 8) == 0) raw += 8;
    return raw;
}

/****************  Escape‑curse chooser (clean version) ************/

/*
 * Presents the menu *n* times (or once if CUR_NOCHOICE). Returns the
 * number of curses actually chosen and fills `out` with their indices.
 * The display is cleared afterwards so we can start narrative fresh.
 */
static int choose_escape_curses_ui(int n, int out[3])
{
    int rolls = any_curse_flag_active(CUR_NOCHOICE) ? 1 : n;
    int taken = 0;

    for (int i = 0; i < rolls; i++)
    {
        int idx = menu_choose_one_curse();   /* weighted picker, UI */
        add_curse_stack(idx);                /* gameplay side‑effect */
        if (taken < 3) out[taken++] = idx;
    }

    /* Wipe the menu clutter so narrative starts clean */
    Term_clear();
    return taken;
}

/******************  Story Fragment helper  ************************/

static void print_story_fragment(byte sil_count, bool treachery_active)
{
    /* Only appear if player has Treachery lineage */
    if (!treachery_active) return;

    static const char *frag[3] = {
        "A lone jewel’s fire flickers against the dark, yet whispers of greed coil round your heart.",
        "Twin jewels blaze, twin desires battle within you—honour and avarice locked in fierce embrace.",
        "Three sacred stars burn in your grasp; their glory sets the shadow seething with envy and dread."
    };
    print_paragraph(frag[sil_count - 1], TERM_L_WHITE);
}

/******************  Deferred kinslayer kills  ********************/

static void defer_kinslayer_kill(bool fails[3])
{
    for (int k = 0; k < 3; k++)
        if (fails[k]) kinslayer_try_kill(k + 1);
}

/* ------------------------------------------------------------------
 * metarun_update_on_exit() – v5, 30 Jul 2025
 * ------------------------------------------------------------------
 * Implements the finalised story/logic flow discussed in chat:
 *   0.  Escape check (silmarils? gift‑of‑Eru?)
 *   1.  Escape‑curse chooser UI
 *   2.  Victory banner & Silmaril paragraph
 *   3.  Temptation of Treachery (3 rolls – stolen Silmarils don’t count)
 *   4.  Story Fragment (pure vs tainted, 1‑3 jewels)
 *   5.  Echoes of Kinslaying / "Kill a Kin" (stop at first kill)
 *   6.  Final pause → apply deferred effects
 *   7.  Persist silmaril/death counters, check run end, save
 *
 *  All narrative helpers (print_heading(), print_paragraph(),
 *  choose_escape_curses_ui(), kinslayer_try_kill(), etc.) are reused.
 * ------------------------------------------------------------------ */
void metarun_update_on_exit(bool died, bool escaped, byte sil_count)
{
    /* -------- Lineage flags -------------------------------------- */
    u32b f_house = c_info[p_ptr->phouse].flags;
    u32b f_race  = p_info[p_ptr->prace].flags;

    bool has_gift_eru   = (f_house | f_race) & RHF_GIFTERU;
    bool allow_treachery = (f_house | f_race) & RHF_TREACHERY;
    bool allow_kinslay   = (f_house | f_race) & RHF_KINSLAYER;

    bool escaped_with_sils = escaped && (sil_count > 0);

        /* Treat as a death unless Eru intervenes */
        if (died && !has_gift_eru)
            metar.deaths++;

    /* ------------------------------------------------------------- */
    /* 0. Branch: did we return with Silmarils?                      */
    /*    – any path that reaches here counts as a "run end" event  */
    /* ------------------------------------------------------------- */
    if (!escaped_with_sils)
    {

        /* Optional narrative: handled elsewhere (death poems) */
        check_run_end();
        save_metaruns();
        return;
    }

    /* ------------------------------------------------------------- */
    /*        Narrative path – escaped with ≥1 Silmaril              */
    /* ------------------------------------------------------------- */
    screen_save();

    /* 0.a  Escape‑curse chooser (UI clears screen when done) */
    int chosen[3] = { -1, -1, -1 };
    int chosen_cnt = choose_escape_curses_ui(sil_count, chosen);

    /* 1.  Show chosen curse lines */
    for (int i = 0; i < chosen_cnt; ++i)
    {
        char buf[128];
        strnfmt(buf, sizeof buf,
                "The curse of %s binds your fate.",
                curse_display_name(chosen[i]));
        print_paragraph(buf, TERM_RED);
    }

    /* 2.  Victory banner & Silmaril paragraph */
    print_heading("Victory Amid Shadow", TERM_YELLOW);
    switch (sil_count)
    {
        case 1:
            print_paragraph("You emerge victorious from darkness, one holy jewel blazing in your grasp. Morgoth’s crown is diminished, yet hope is rekindled, though shadow lingers.", TERM_WHITE);
            break;
        case 2:
            print_paragraph("You escape triumphant, two Silmarils blazing fiercely in your hands. Morgoth roars in wrath; his pride is wounded deeply. Your spirit exults, yet your heart begins to feel their burning weight.", TERM_WHITE);
            break;
        case 3:
            print_paragraph("All three stolen stars blaze now in your hands; Morgoth’s crown lies darkened. Such triumph has not been known since Fëanor himself dreamed it—but even as victory soars, your heart trembles beneath their burning glory.", TERM_WHITE);
            break;
    }

    /* 3.  Temptation of Treachery (if lineage allows) */
    byte stolen = 0;
    if (allow_treachery)
    {
        static const int pct[3] = { 20, 50, 95 };
        print_heading("Temptation of Treachery", TERM_L_UMBER);

        for (int i = 0; i < sil_count; ++i)
        {
            bool fail = (rand_int(100) < pct[i]);
            if (fail) stolen++;
            print_paragraph(
                fail ?
                    "Greed whispers softly, and you withhold the jewel’s light, betraying even yourself." :
                    "The jewel shines uncorrupted; you master desire and choose honour.",
                fail ? TERM_RED : TERM_L_WHITE);
        }

        if (stolen)
            print_paragraph("In shadows your deeds are recorded—tainted victory shall diminish the jewel’s blessing.", TERM_L_DARK);
    }

    byte final_sils = sil_count - stolen;
    bool treachery_occurred = (stolen > 0);

    /* 4.  Story fragment */
    {
        print_heading("", TERM_YELLOW); /* blank line */
        if (!treachery_occurred)
        {
            const char *pure_frag[3] = {
                "A single star reclaimed, hope rekindled faintly in Middle‑earth. Yet Morgoth laughs still, for two remain bound in shadow.",
                "Two jewels shine again beneath sky; Morgoth’s power falters greatly. Yet you feel their brilliance burning; temptation ever near.",
                "All three jewels, radiant and pure, blaze again beneath stars. Morgoth’s power breaks. Triumph is absolute, your soul soaring."
            };
            print_paragraph(pure_frag[final_sils-1], TERM_L_WHITE);
        }
        else
        {
            const char *tainted_frag[3] = {
                "Though victory is yours, its memory darkens. Trust is fragile, and your spirit heavy beneath secret betrayal.",
                "Your heart trembles: Morgoth sees clearly your treachery—he smiles grimly, knowing darkness still dwells in you.",
                "Greatest triumph now mingled with darkest shame. Morgoth’s laughter echoes bitterly—he senses your fall."
            };
            print_paragraph(tainted_frag[final_sils-1], TERM_RED);
        }
    }

    /* 5.  Echoes of Kinslaying / "Kill a Kin" */
    bool deferred_kill[3] = { false, false, false };
    if (allow_kinslay)
    {
        static const int kin_pct[3] = { 20, 50, 95 };
        print_heading("Echoes of Kinslaying – Kill a Kin", TERM_L_RED);

        for (int k = 0; k < 3; ++k)
        {
            bool fail = (rand_int(100) < kin_pct[k]);
            deferred_kill[k] = fail;

            const char *txt = NULL;
            switch (k)
            {
                case 0: txt = fail ?
                    "\"Alqualondë’s Grief\"\nBlood stains starlit waves. Your hand remembers the swords at Alqualondë—first grief, first guilt." :
                    "The sorrow of Alqualondë passes over you—your spirit holds fast, blood unstained.";
                    break;
                case 1: txt = fail ?
                    "\"Ruin of Doriath\"\nAgain your hand recalls tragedy—fallen halls of Menegroth, Dior’s blood shed beneath stolen starlight." :
                    "Memory of Doriath rises briefly, but your blade remains clean, honour upheld.";
                    break;
                case 2: txt = fail ?
                    "\"Tragedy at Sirion\"\nEchoes rise from Sirion—Elwing’s flight, blood and betrayal. Once more your blade draws innocent blood, sealing doom anew." :
                    "You resist dark whispers recalling Sirion—your sword is stayed, mercy unbroken.";
                    break;
            }
            print_paragraph(txt, fail ? TERM_RED : TERM_L_WHITE);

            /* Stop at first failure */
            if (fail) { k = 3; }
        }

        if (deferred_kill[0] || deferred_kill[1] || deferred_kill[2])
            print_paragraph("Blood now stains your triumph, your fate forever woven with grief and shame.", TERM_L_DARK);
    }

    /* 6.  Final pause */
    int wid, hgt; Term_get_size(&wid, &hgt);
    prt("[Press any key to continue]", hgt - 1, 1);
    (void)inkey();

    /* 7.  Apply deferred side‑effects & persist */
    screen_load();

    if (allow_kinslay) defer_kinslayer_kill(deferred_kill);

    metar.silmarils += final_sils;
    check_run_end();
    save_metaruns();
}


/* ======================  run-state logic  ====================== */
/* ------------------------------------------------------------------ *
 *  Decide whether the current run just ended, and react accordingly. *
 *  Message text adapts automatically if you set LOSECON_DEATHS = 1.  *
 * ------------------------------------------------------------------ */
static void check_run_end(void)
{
    int max_deaths = MAX(1, LOSECON_DEATHS - 3 * curse_flag_count(CUR_DEATH));
    if (metar.silmarils >= WINCON_SILMARILS) {
        msg_print("\n*** VICTORY! 15 Silmarils recovered – a new age dawns… ***\n");
        message_flush();
        start_new_metarun();

    } else if (metar.deaths >= max_deaths){
            msg_print(format(
                "\n*** DEFEAT! %d hero%s fallen – the run is lost. ***\n",
                max_deaths, (max_deaths == 1) ? " has" : "es have"));
            message_flush();
            start_new_metarun();
        }
}

/* ------------------------------------------------------------------
 *  Start a brand-new meta-run.
 *  We snapshot the finished run **after** the array has been grown,
 *  so we only write once and always with the final pointer.
 * ------------------------------------------------------------------ */
static void start_new_metarun(void)
{
    /* Save old state */
    s16b old_max   = metarun_max;
    metarun *old   = metaruns;

    /* Try to allocate a new array for one more run */
    metarun *tmp = C_RNEW(old_max + 1, metarun);
    if (!tmp) {
        /* Allocation failed — keep everything as is */
        return;
    }

    /* Copy over the previous runs (if any) */
    if (old) {
        C_COPY(tmp, old, old_max, metarun);
    }

    /* Free the old array just once */
    FREE(old);

    /* Commit the new array and size */
    metaruns    = tmp;
    metarun_max = old_max + 1;

    /* Initialize the brand-new slot */
    reset_defaults(&metaruns[metarun_max - 1]);
    metaruns[metarun_max - 1].id = metar.id + 1;

    /* Update globals */
    current_run      = metarun_max - 1;
    metar             = metaruns[current_run];
    metarun_created  = true;

    /* Persist and prepare */
    save_metaruns();      /* safe now that metaruns≠NULL */ 
    ensure_run_dir(&metar);
}


/*
 * Enhanced print_metarun_stats():
 * - Draws bracketed progress bars for Silmarils & Deaths with colored stars
 * - Displays numeric counts next to each bar
 * - Aligns labels & values for a cleaner layout
 * - Lists active curses with D: and (optionally) P: details
 */
/* Updated print_metarun_stats(): prettier layout, star & death bars, curses list */
void print_metarun_stats(void)
{
    int row = 1;
    int col = 2;
    char buf[128];
    int x;

    /* Save & clear screen */
    screen_save();
    Term_clear();

    /* Title */
    Term_putstr(col, row++, -1, TERM_YELLOW, "=== Current Story Statistics ===");
    row++;

    /* Run ID */
    snprintf(buf, sizeof buf, "Run-ID     : %u", metar.id);
    Term_putstr(col, row++, -1, TERM_WHITE, buf);
    row++;

    /* Silmarils bar */
    snprintf(buf, sizeof buf, "Silmarils  : ");
    Term_putstr(col, row, -1, TERM_WHITE, buf);
    x = col + strlen(buf);
    for (int i = 0; i < WINCON_SILMARILS; i++) {
        byte attr = (i < metar.silmarils) ? TERM_L_GREEN : TERM_L_WHITE;
        Term_putch(x++, row, attr, '*');
    }
    snprintf(buf, sizeof buf, "  (%d/%d)", metar.silmarils, WINCON_SILMARILS);
    Term_putstr(x + 1, row++, -1, TERM_WHITE, buf);
    // row++;

    /* Deaths bar */
    snprintf(buf, sizeof buf, "Deaths     : ");
    Term_putstr(col, row, -1, TERM_WHITE, buf);
    x = col + strlen(buf);
    for (int i = 0; i < LOSECON_DEATHS; i++) {
        byte attr = (i < metar.deaths) ? TERM_RED : TERM_L_WHITE;
        Term_putch(x++, row, attr, 'x');
    }
    snprintf(buf, sizeof buf, "  (%d/%d)", metar.deaths, LOSECON_DEATHS);
    Term_putstr(x + 1, row++, -1, TERM_WHITE, buf);
    row += 2;

    /* Active curses list */
    Term_putstr(col, row++, -1, TERM_YELLOW, "Active Curses:");
#ifdef DEBUG_CURSES
    Term_putstr(col, row++, -1, TERM_L_DARK, "(showing D:stacks and P:effect)");
#endif
    for (int id = 0; id < z_info->cu_max; id++) {
        byte cnt = CURSE_GET(id);
        if (!cnt) continue;
        /* Build line: id, name, D:count, optional P:text */
        cptr name = cu_name + cu_info[id].name;
#ifdef DEBUG_CURSES
        cptr pow = cu_text + cu_info[id].power;
        snprintf(buf, sizeof buf, " %2d: %-20s D:%d P:%s", id, name, cnt, pow);
#else
        snprintf(buf, sizeof buf, " %2d: %-20s D:%d", id, name, cnt);
#endif
        Term_putstr(col + 2, row++, -1, TERM_WHITE, buf);
    }
    row++;

    /* Prompt and restore */
    Term_putstr(col, row++, -1, TERM_L_DARK, "[Press any key to continue]");
    (void)inkey();
    screen_load();
}

/* compact table of all meta-runs */
void list_metaruns(void)
{
    screen_save();
    Term_clear();
    c_prt(TERM_L_GREEN, "Meta-run history", 1, 2);
    c_put_str(TERM_L_DARK,
              " ID       Sil  Dth  Res  Last played", 3, 2);

    int row = 4;
    for (s16b i = 0; i < metarun_max; i++) {
        const metarun *m = &metaruns[i];
        char res = (m->silmarils >= WINCON_SILMARILS) ? 'W' :
                   (m->deaths    >= LOSECON_DEATHS)   ? 'L' : ' ';
        char date[16];
        strftime(date, sizeof date, "%Y-%m-%d",
                 localtime((time_t*)&m->last_played));

        c_put_str((i == current_run) ? TERM_YELLOW : TERM_WHITE,
                  format("%08u   %2d   %2d   %c   %s",
                         m->id, m->silmarils, m->deaths, res, date),
                  row++, 2);

        if (row >= 23 && i+1 < metarun_max) {   /* page break */
            c_put_str(TERM_L_DARK, "[more – any key]", 23, 2);
            inkey();  Term_clear();
            row = 4;
            c_prt(TERM_L_GREEN, "Meta-run history (cont.)", 1, 2);
            c_put_str(TERM_L_DARK,
                      " ID       Sil  Dth  Res  Last played", 3, 2);
        }
    }
    c_put_str(TERM_L_DARK, "Press any key to return.", row+1, 2);
    inkey();
    screen_load();
}

void show_known_curses_menu(void)
{
    int shown = 0;
    int row = 2;
    int id;

    log_debug("show_known_curses_menu: metar.curses_seen=0x%08lX",
            (unsigned long) metar.curses_seen);


    /* Collect and count first */
    for (id = 0; id < (int)z_info->cu_max; id++)
        if (CURSE_SEEN(id)) {
                shown++;
                int seen = CURSE_SEEN(id) ? 1 : 0;
                log_debug("show_known_curses_menu: id=%d, name='%s', Seen=%d",
                id, cu_name + cu_info[id].name, seen);
            }
    if (!shown) {
        msg_print("You have not identified any curses yet.");
        return;
    }

    screen_save();
    Term_clear();
    Term_putstr(1, 0, -1, TERM_L_WHITE + TERM_SHADE, "Known Curses:");

    row = 2;
    for (id = 0; id < (int)z_info->cu_max; id++)
    {
        if (!CURSE_SEEN(id)) continue;

        curse_type *c = &cu_info[id];
        cptr cname  = cu_name + c->name;
        cptr cdesc  = cu_text + c->text;
        cptr cpower = cu_text + c->power;

        /* Name */
        Term_putstr(1, row, -1, TERM_L_RED, cname); row++;
        /* Poem / description */
        Term_putstr(3, row, -1, TERM_WHITE, cdesc); row++;
        /* Power line (P:) */
        Term_putstr(3, row, -1, TERM_L_DARK, cpower); row++;

        /* Page wrap (match self_knowledge style) */
        if (row >= 21) {
            Term_putstr(1, row, -1, TERM_L_WHITE, "(press any key)");
            (void)inkey();
            Term_clear();
            Term_putstr(1, 0, -1, TERM_L_WHITE + TERM_SHADE, "Known Curses:");
            row = 2;
        }
    }

    Term_putstr(1, row+1, -1, TERM_L_WHITE, "(press any key)");
    (void)inkey();
    screen_load();
}

